# Teloude

Windows-first personal backup that uses **your own Telegram account** (MTProto via Telethon, not the Bot API) as private storage.
Each storage is a private forum supergroup; folders map to Forum Topics; the real hierarchy lives in local SQLite and in
self-describing message captions, so another PC can rediscover and restore everything. Backup, not sync: **local files are never deleted automatically.**

## Run from source
```bash
python -m venv .venv && . .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -e ".[dev]"
export TELOUDE_API_ID=... TELOUDE_API_HASH=...       # optional; otherwise the login screen asks (my.telegram.org/apps)
python -m app
```
API credentials are never in the source. They come from the environment or the login screen and are stored with Windows DPAPI.

## Test / lint
```bash
python -m pytest -q      # 129 pass, 1 Windows-only skip on Linux
python -m ruff check .
python scripts/benchmarks.py   # fake-transport benchmarks -> docs/BENCHMARKS.md
```

## Build the Windows installer (on Windows)
`powershell -File scripts\build_windows.ps1` runs lint+tests, regenerates the icon, builds with PyInstaller (`installer/teloude.spec`),
builds the installer with Inno Setup (`installer/teloude.iss`) and runs `scripts/windows_verify.py` against the packaged EXE.

See `docs/` for REQUIREMENTS, ARCHITECTURE, IMPLEMENTATION_PLAN, VERIFICATION (what is and is not verified) and BENCHMARKS.
