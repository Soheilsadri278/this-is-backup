# PyInstaller spec - run on Windows:  pyinstaller installer/teloude.spec --noconfirm
# One-dir build (fast start, fewer antivirus false positives than one-file).
from pathlib import Path

ROOT = Path(SPECPATH).parent  # noqa: F821
ICON = str(ROOT / "assets" / "icon.ico")

a = Analysis(  # noqa: F821
    [str(ROOT / "app" / "__main__.py")],
    pathex=[str(ROOT)],
    datas=[(str(ROOT / "assets"), "assets")],
    hiddenimports=["telethon.network.connection.tcpmtproxy", "PIL._tkinter_finder"],
    excludes=["tkinter", "PySide6.QtWebEngineCore", "PySide6.QtWebEngineWidgets", "PySide6.Qt3DCore",
              "PySide6.QtQuick", "PySide6.QtQml", "PySide6.QtMultimedia", "PySide6.QtPdf"],
    noarchive=False,
)
pyz = PYZ(a.pure)  # noqa: F821
exe = EXE(  # noqa: F821
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="Teloude",
    console=False,
    icon=ICON,  # embedded into Teloude.exe
    version=str(ROOT / "installer" / "version_info.txt"),
    upx=False,
)
coll = COLLECT(exe, a.binaries, a.datas, name="Teloude", upx=False)  # noqa: F821
