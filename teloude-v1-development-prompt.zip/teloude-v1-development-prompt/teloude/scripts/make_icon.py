"""Generate assets/icon.ico (16..256 px, all embedded) and assets/icon.png with Pillow."""
from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw

SIZE = 1024


def build() -> Image.Image:
    img = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    grad = Image.new("RGBA", (SIZE, SIZE))
    px = grad.load()
    for y in range(SIZE):
        for x in range(SIZE):
            t = (x + y) / (2 * SIZE)
            px[x, y] = (int(77 + (94 - 77) * t), int(163 + (92 - 163) * t), int(255 + (230 - 255) * t), 255)
    mask = Image.new("L", (SIZE, SIZE), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, SIZE - 1, SIZE - 1), radius=int(SIZE * 0.22), fill=255)
    img.paste(grad, (0, 0), mask)
    d = ImageDraw.Draw(img)
    s = SIZE
    for box in ((0.22, 0.40, 0.54, 0.70), (0.38, 0.28, 0.72, 0.66), (0.55, 0.40, 0.79, 0.70)):
        d.ellipse([c * s for c in box], fill="white")
    d.rounded_rectangle((0.30 * s, 0.50 * s, 0.72 * s, 0.70 * s), radius=int(0.08 * s), fill="white")
    arrow = [(0.5, 0.40), (0.62, 0.54), (0.54, 0.54), (0.54, 0.66), (0.46, 0.66), (0.46, 0.54), (0.38, 0.54)]
    d.polygon([(x * s, y * s) for x, y in arrow], fill=(79, 125, 240, 255))
    return img


def main() -> None:
    out = Path(__file__).resolve().parents[1] / "assets"
    out.mkdir(exist_ok=True)
    img = build()
    img.resize((512, 512), Image.LANCZOS).save(out / "icon.png")
    img.save(out / "icon.ico", sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
    print("wrote", out / "icon.ico")


if __name__ == "__main__":
    main()
