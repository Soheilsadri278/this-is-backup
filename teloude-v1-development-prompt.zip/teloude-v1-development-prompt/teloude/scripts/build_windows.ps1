# Build Teloude for Windows: venv -> tests -> icon -> PyInstaller -> Inno Setup -> verification.
# Requirements: Python 3.12+, Inno Setup 6 (iscc.exe on PATH or in the default install dir).
$ErrorActionPreference = "Stop"
Set-Location (Split-Path $PSScriptRoot -Parent)

python -m venv .venv
.\.venv\Scripts\python -m pip install --upgrade pip
.\.venv\Scripts\python -m pip install -e ".[dev,build]"

.\.venv\Scripts\python -m ruff check .
.\.venv\Scripts\python -m pytest -q          # includes the Windows-only DPAPI tests
.\.venv\Scripts\python scripts\make_icon.py  # regenerates assets\icon.ico (7 sizes)

Remove-Item -Recurse -Force build, dist -ErrorAction SilentlyContinue
.\.venv\Scripts\pyinstaller installer\teloude.spec --noconfirm

$iscc = (Get-Command iscc.exe -ErrorAction SilentlyContinue).Source
if (-not $iscc) { $iscc = "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe" }
& $iscc installer\teloude.iss

.\.venv\Scripts\python scripts\windows_verify.py --exe dist\Teloude\Teloude.exe --installer dist\Teloude-Setup-1.0.0.exe
Write-Host "Done: dist\Teloude-Setup-1.0.0.exe"
