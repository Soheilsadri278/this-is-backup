"""Where Teloude keeps its data. Nothing here is a secret."""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from pathlib import Path

APP_NAME = "Teloude"
APP_VERSION = "1.0.0"


@dataclass(frozen=True)
class AppPaths:
    root: Path

    @property
    def db(self) -> Path:
        return self.root / "teloude.db"

    @property
    def logs(self) -> Path:
        return self.root / "logs"

    @property
    def secrets(self) -> Path:
        return self.root / "secrets"

    @property
    def cache(self) -> Path:
        return self.root / "cache"

    def ensure(self) -> AppPaths:
        for p in (self.root, self.logs, self.secrets, self.cache):
            p.mkdir(parents=True, exist_ok=True)
        return self


def default_data_dir() -> Path:
    override = os.environ.get("TELOUDE_DATA_DIR")
    if override:
        return Path(override)
    if sys.platform == "win32":
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
        return Path(base) / APP_NAME
    return Path(os.environ.get("XDG_DATA_HOME", str(Path.home() / ".local" / "share"))) / APP_NAME


def app_paths(root: Path | None = None) -> AppPaths:
    return AppPaths(root or default_data_dir()).ensure()
