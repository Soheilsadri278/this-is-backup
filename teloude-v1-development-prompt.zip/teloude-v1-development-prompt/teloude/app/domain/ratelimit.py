"""Asynchronous token-bucket rate limiter.

Design notes
------------
* ``acquire`` *reserves* tokens synchronously (no await between read/modify/write, so it is
  race-free on one event loop) and then sleeps only for *its own* deficit. Many concurrent
  uploaders therefore share one global budget **without being serialised** behind a lock or a
  blocking ``time.sleep``.
* ``rate=None`` means unlimited: ``acquire`` returns without awaiting anything.
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable, Callable


class TokenBucket:
    def __init__(
        self,
        rate: float | None,
        burst_seconds: float = 0.5,
        clock: Callable[[], float] = time.monotonic,
        sleep: Callable[[float], Awaitable[None]] = asyncio.sleep,
    ):
        self._clock = clock
        self._sleep = sleep
        self._burst_seconds = burst_seconds
        self._rate: float | None = None
        self._capacity = 0.0
        self._tokens = 0.0
        self._last = clock()
        self.total_throttled_seconds = 0.0
        self.set_rate(rate)

    @property
    def rate(self) -> float | None:
        return self._rate

    def set_rate(self, rate: float | None) -> None:
        if rate is not None and rate <= 0:
            raise ValueError("rate must be positive or None")
        self._refill()
        was_unlimited = self._rate is None
        self._rate = rate
        if rate is None:
            self._capacity = 0.0
            self._tokens = 0.0
        else:
            self._capacity = rate * self._burst_seconds
            self._tokens = self._capacity if was_unlimited else min(self._tokens, self._capacity)
        self._last = self._clock()

    def _refill(self) -> None:
        now = self._clock()
        if self._rate is not None:
            self._tokens = min(self._capacity, self._tokens + (now - self._last) * self._rate)
        self._last = now

    async def acquire(self, nbytes: int) -> float:
        """Wait until ``nbytes`` may be sent. Returns the seconds this caller waited."""
        if self._rate is None or nbytes <= 0:
            return 0.0
        self._refill()
        self._tokens -= nbytes  # may go negative: that is the "debt" the caller waits out
        if self._tokens >= 0:
            return 0.0
        wait = -self._tokens / self._rate
        self.total_throttled_seconds += wait
        try:
            await self._sleep(wait)
        except asyncio.CancelledError:
            self._tokens += nbytes  # refund so a cancelled caller does not starve others
            raise
        return wait
