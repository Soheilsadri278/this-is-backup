# Verification status (honest)
Environment used: Linux sandbox, Python 3.11 (project targets 3.12+; code is 3.11-compatible), PySide6 6.11 offscreen, Telethon 1.45. No Windows, no Telegram account/credentials.

| Subsystem | Implemented | Tested here | Not yet verified / blocked |
|---|---|---|---|
| Scanner, hashing, change detection | yes | yes (unit) | huge folders (1M files) |
| SQLite, migrations, WAL, corruption quarantine | yes | yes | |
| Pipelined upload, bounded concurrency, ordering | yes | yes (fake transport) | real Telegram throughput/flood behaviour |
| Retry/backoff/reconnect/resume/session loss | yes | yes (fault injection) | real network drops |
| Speed limiter | yes | yes | |
| Crash recovery + adopt-after-crash | yes | yes (simulated process death) | real power loss |
| Duplicates, versions, cancel, pause | yes | yes | |
| Restore (traversal, overwrite decision, verify, resume) | yes | yes | |
| Discovery on another PC | yes | yes (fake) | live `iter_dialogs`/topics paging |
| Search / preview | yes | yes (PNG, text) | RAW (heuristic, untested on real RAW), PDF text only, video thumb only if Telegram supplies one |
| Telethon adapter | yes | request construction + error mapping with a recording client | **any live Telegram call: login, forum creation, topic creation, SendMedia, download** |
| MTProto proxy | yes (plain + dd) | secret parsing, wiring | live proxy; `ee` fake-TLS is unsupported by Telethon and rejected explicitly |
| UI (login, pages, tray logic, dialogs, proxy sheet) | yes | offscreen render tests incl. painted-area regression | real Windows compositing, real tray, toast notifications |
| DPAPI secret store | yes | Windows-only test (skipped on Linux) | run on Windows |
| PyInstaller / Inno Setup | scripts written | static regression tests on spec/iss/ico | **never built or run; needs Windows** (`scripts/windows_verify.py`) |

Known limitations: files are uploaded one at a time (parts are pipelined; many tiny files are slower), small files <=10 MiB are not resumable across restarts (cheap to resend),
Telegram does not document upload-session retention, so resume after long gaps is attempted and falls back to a new session if rejected.
